-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 08:51 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrismart`
--

-- --------------------------------------------------------

--
-- Table structure for table `crophistory`
--

CREATE TABLE `crophistory` (
  `HistoryId` int(11) NOT NULL,
  `CropType` varchar(20) NOT NULL,
  `date` varchar(20) DEFAULT NULL,
  `HarvestYield` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crophistory`
--

INSERT INTO `crophistory` (`HistoryId`, `CropType`, `date`, `HarvestYield`) VALUES
(15, 'beans', '05/04/2023', '300kgs');

-- --------------------------------------------------------

--
-- Table structure for table `croprecommendations`
--

CREATE TABLE `croprecommendations` (
  `CropId` int(11) NOT NULL,
  `CropName` varchar(200) NOT NULL,
  `PlantingSeason` varchar(200) NOT NULL,
  `RecommendedPra` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `croprecommendations`
--

INSERT INTO `croprecommendations` (`CropId`, `CropName`, `PlantingSeason`, `RecommendedPra`) VALUES
(27, 'Banana', 'Season 4', 3),
(28, 'Maize', 'Season 2', 5),
(29, 'potato', 'Season 4', 6),
(32, 'Sweet potatoes', 'season 2', 4);

-- --------------------------------------------------------

--
-- Table structure for table `soilmoisturedata`
--

CREATE TABLE `soilmoisturedata` (
  `DataId` int(20) NOT NULL,
  `Timestamp` int(20) NOT NULL,
  `MoistureLevel` int(20) NOT NULL,
  `CropHistory` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crophistory`
--
ALTER TABLE `crophistory`
  ADD PRIMARY KEY (`HistoryId`);

--
-- Indexes for table `croprecommendations`
--
ALTER TABLE `croprecommendations`
  ADD PRIMARY KEY (`CropId`);

--
-- Indexes for table `soilmoisturedata`
--
ALTER TABLE `soilmoisturedata`
  ADD PRIMARY KEY (`DataId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crophistory`
--
ALTER TABLE `crophistory`
  MODIFY `HistoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `croprecommendations`
--
ALTER TABLE `croprecommendations`
  MODIFY `CropId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
