-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2024 at 06:48 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rp_usap`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Username`, `Password`) VALUES
(1, 'Admin', 'Admin@321');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `aid` int(11) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `qid` int(11) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`aid`, `Description`, `qid`, `pid`) VALUES
(13, 'Approved', 18, 3),
(14, 'Canceled', 16, 3),
(15, 'Approved', 20, 1),
(16, 'Approved', 22, 3);

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE `hod` (
  `hid` int(11) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`hid`, `Firstname`, `Lastname`, `Department`, `Username`, `Password`) VALUES
(1, 'NIYIGABA', 'Ephrem', 'ICT', 'Ephrem', 'Ephrem@123'),
(3, 'Arakarama', 'Viateur', 'Electrical', 'Viateur', 'Viateur@123'),
(4, 'umwizerwa', 'JeanPierre', 'Automobile', 'Pierre', 'Pierre@123'),
(5, 'Diane', 'Mbabazi', 'Hospitality', 'Diane', 'Diane@123');

-- --------------------------------------------------------

--
-- Table structure for table `professionor`
--

CREATE TABLE `professionor` (
  `pid` int(11) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `professionor`
--

INSERT INTO `professionor` (`pid`, `Firstname`, `Lastname`, `Username`, `Password`, `type`) VALUES
(1, 'Gabriel', 'NISHIMWE', 'Gabe', 'Gabriel@123', 'Sport'),
(3, 'Balinda', 'Mary', 'Mary', 'Mary@123', 'Nurse'),
(5, 'Ganza', 'Patricie', 'Ganza', 'Ganza@123', 'Warden'),
(6, 'Ahishakiye', 'Philbert', 'kim', 'Philbert@123', 'counselor');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(11) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `Staff` varchar(30) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `Description`, `status`, `Staff`, `uid`) VALUES
(16, 'Proof of Medical', 'Pending', 'Nurse', 1),
(17, 'Balon', 'Pending', 'Sport', 1),
(18, 'Medical report', 'Pending', 'Nurse', 7),
(19, 'Request For Hall', 'Pending', 'Sport', 7),
(20, 'muraho neza', 'Pending', 'Sport', 8),
(21, 'i need mentorship on studies', 'Pending', 'counselor', 9),
(22, 'I am sick', 'Pending', 'Nurse', 8);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `Description` text NOT NULL,
  `Status` varchar(50) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `hid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `Description`, `Status`, `uid`, `hid`) VALUES
(5, 'Medical report', '', 7, 1),
(6, 'Proof of Medical', 'Canceled', 1, 1),
(7, 'muraho neza', 'Approved', 8, 1),
(8, 'Medical report', 'Approved', 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Sid` int(11) NOT NULL,
  `Regno` varchar(9) NOT NULL,
  `Firstname` varchar(255) NOT NULL,
  `Lastname` varchar(255) NOT NULL,
  `Age` int(2) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Class` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Sid`, `Regno`, `Firstname`, `Lastname`, `Age`, `Gender`, `Class`) VALUES
(1, '21RP07775', 'RUGABA', 'Innocent Gilbert', 23, 'Male', 'IT'),
(2, '21RP00722', 'ISHIMWE', 'Didier', 23, 'Male', 'IT'),
(3, '22RP10126', 'Ahishakiye', 'Philbert', 23, 'M', 'L6 Y2'),
(4, '22RP12049', 'Tuyizere', 'Ignace', 23, 'M', 'L6 Y2'),
(5, '22RP11439', 'GANZA', 'PATRICIE', 20, 'Female', 'CURNARY'),
(6, '22RP10123', 'Niyongira', 'Ruth', 20, 'Female', 'Mechanical');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `Reg_No` varchar(10) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Sid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `Reg_No`, `Firstname`, `Lastname`, `Username`, `Password`, `Sid`) VALUES
(1, '21RP07775', 'Mugisha', 'Fidele', 'Fidele', 'Fidele@123', 1),
(6, '22RP11969', 'Eliane', 'Iradukunda', 'Eliane', 'Eliane@123', NULL),
(7, '21RP00722', 'ISHIMWE', 'Didier', 'Bwasisi', '321', NULL),
(8, '22RP10126', 'Ahishakiye', 'Philbert', 'kim', 'Kimich@123', NULL),
(9, '22RP12049', 'Tuyizere', 'Ignace', 'Ignace', 'Ignace@123', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `qid` (`qid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
  ADD PRIMARY KEY (`hid`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `professionor`
--
ALTER TABLE `professionor`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`qid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`),
  ADD KEY `hid` (`hid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `fk_user_student` (`Sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `hod`
--
ALTER TABLE `hod`
  MODIFY `hid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `professionor`
--
ALTER TABLE `professionor`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `Sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`qid`) REFERENCES `questions` (`qid`),
  ADD CONSTRAINT `answers_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `professionor` (`pid`);

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`);

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`hid`) REFERENCES `hod` (`hid`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_student` FOREIGN KEY (`Sid`) REFERENCES `student` (`Sid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
