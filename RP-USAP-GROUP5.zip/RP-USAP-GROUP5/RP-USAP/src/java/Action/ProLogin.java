package Action;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ProLogin extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String uname = request.getParameter("uname");
        String pass = request.getParameter("pass");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String role = checkUserRole(uname, pass);
        if (role != null) {
            HttpSession session = request.getSession();
            session.setAttribute("uname", uname);
            session.setAttribute("role", role);

            // Redirect based on the role
            if (role.equalsIgnoreCase("professionor")) {  // using equalsIgnoreCase to avoid case mismatch
                response.sendRedirect("Professionor/ProHome.jsp");
            } else if (role.equalsIgnoreCase("admin")) {
                response.sendRedirect("AdminHome.jsp");
            } else if (role.equalsIgnoreCase("user")) {
                response.sendRedirect("UserHome.jsp");
            } else if (role.equalsIgnoreCase("hod")) {  // updated from "HOD" to "hod"
                response.sendRedirect("HODHome.jsp");
            }
        } else {
            // Set error message and forward back to the login page
            request.setAttribute("errorMessage", "Invalid Credentials! Try Again!");
            request.getRequestDispatcher("index.html").forward(request, response);
        }
    }

    private String checkUserRole(String uname, String pass) {
        String role = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rp_usap", "root", "");

            // Check in professionor table
            String query = "SELECT Password FROM professionor WHERE Username = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            rs = ps.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("Password");
                if (storedPassword.equals(pass)) {
                    role = "professionor";
                    return role;
                }
            }

            // Check in admin table
            query = "SELECT Password FROM admin WHERE Username = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            rs = ps.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("Password");
                if (storedPassword.equals(pass)) {
                    role = "admin";
                    return role;
                }
            }

            // Check in user table
            query = "SELECT Password FROM user WHERE Username = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            rs = ps.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("Password");
                if (storedPassword.equals(pass)) {
                    role = "user";
                    return role;
                }
            }

            // Check in hod table
            query = "SELECT Password FROM hod WHERE Username = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            rs = ps.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("Password");
                if (storedPassword.equals(pass)) {
                    role = "hod";  // Ensure this is consistent with your role checks
                    return role;
                }
            }

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return role;
    }
}
