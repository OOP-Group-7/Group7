package Action;

import java.io.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.*;
import javax.servlet.http.*;
public class AddH extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fname=request.getParameter("fname");
        String lname=request.getParameter("lname");
        String uname=request.getParameter("uname");
        String dept=request.getParameter("depart");
        String pass=request.getParameter("pass");
        
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rp_usap","root","");
            String sql = "INSERT INTO hod(Firstname,Lastname,Department,Username,Password) VALUES(?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(4, uname);
            ps.setString(3, dept);
            ps.setString(5, pass);
            ps.executeUpdate();
            out.print("Done!");
            response.sendRedirect("DisplayHOD.jsp");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        
    }
}
