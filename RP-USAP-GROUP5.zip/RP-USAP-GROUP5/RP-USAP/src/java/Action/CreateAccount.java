package Action;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CreateAccount extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String regno = request.getParameter("regno");
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String uname = request.getParameter("uname");
        String pass = request.getParameter("pass");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rp_usap", "root", "");

            String checkSql = "SELECT * FROM student WHERE Regno = ?";
            ps = con.prepareStatement(checkSql);
            ps.setString(1, regno);
            rs = ps.executeQuery();

            if (rs.next()) {
                String insertSql = "INSERT INTO user(Reg_No, Firstname, Lastname, Username, Password) VALUES(?, ?, ?, ?, ?)";
                ps = con.prepareStatement(insertSql);
                ps.setString(1, regno);
                ps.setString(2, fname);
                ps.setString(3, lname);
                ps.setString(4, uname);
                ps.setString(5, pass);
                ps.executeUpdate();

                response.sendRedirect("Login.jsp");
            } else {
                out.print("<body><center><font color='red'>Invalid Registration Number!</font></center><body>");
                RequestDispatcher rd = request.getRequestDispatcher("Createacc.jsp");
                rd.include(request, response);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            out.print("Error occurred: " + ex.getMessage());
            RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
            rd.include(request, response);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
